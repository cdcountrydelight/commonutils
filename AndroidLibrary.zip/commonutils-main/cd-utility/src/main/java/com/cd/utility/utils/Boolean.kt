package com.cd.utility.utils

fun Boolean?.isTrue() = this == true

fun Boolean?.isNotTrue() = !this.isTrue()