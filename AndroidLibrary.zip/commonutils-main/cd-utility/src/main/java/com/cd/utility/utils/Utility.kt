package com.cd.utility.utils

import android.app.Activity
import android.content.Context
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.cd.packaging.BuildConfig
import com.cd.packaging.PackagingApplication
import com.cd.packaging.R
import com.cd.packaging.login.model.TimeSlot
import com.cd.packaging.room.FranchiseCenterSummary
import com.cd.packaging.room.SkuDataConverter.FULLY_DISPATCHED
import com.cd.packaging.room.SkuDataConverter.FULLY_RECEIVED
import com.cd.packaging.routes.model.InventoryType
import com.cd.packaging.routes.model.TableDetails
import com.cd.packaging.ui.main.activity.InventoryProductActivity.Companion.CLOSING_STOCK
import com.cd.packaging.ui.main.activity.InventoryProductActivity.Companion.RECONCILIATION
import com.cd.packaging.ui.main.activity.InventoryProductActivity.Companion.RETURN
import com.cd.packaging.ui.main.fragment.SettingsFragment.Companion.DISPATCHER
import com.cd.packaging.ui.main.fragment.SettingsFragment.Companion.MODIFIER
import com.cd.packaging.ui.main.fragment.SettingsFragment.Companion.PACKER
import com.cd.packaging.ui.main.fragment.SettingsFragment.Companion.PICKER
import com.cd.packaging.ui.main.fragment.SettingsFragment.Companion.SKU_PACKER
import com.cd.packaging.ui.main.fragment.SettingsFragment.Companion.SUPER_PACKER
import com.cd.packaging.ui.main.model.Result
import com.cd.packaging.utils.Constants.InstantStatus.CANCELLED
import com.cd.packaging.utils.Constants.InstantStatus.DB_ALLOCATED
import com.cd.packaging.utils.Constants.InstantStatus.DELIVERED
import com.cd.packaging.utils.Constants.InstantStatus.NON_DELIVERED
import com.cd.packaging.utils.Constants.InstantStatus.OUT_FOR_DELIVERY
import com.cd.packaging.utils.Constants.InstantStatus.PACKAGER_ALLOCATED
import com.cd.packaging.utils.Constants.InstantStatus.PACKAGING_DONE
import com.cd.packaging.utils.Constants.InstantStatus.PACKAGING_PARTIAL
import com.cd.packaging.utils.Constants.InstantStatus.RECEIVED
import com.cd.packaging.utils.Constants.InventoryVisibility.LOCAL_DATA
import com.cd.packaging.utils.Constants.InventoryVisibility.NO_DATA
import com.cd.packaging.utils.Constants.InventoryVisibility.SERVER_DATA
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONObject
import retrofit2.HttpException
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Date
import java.util.Locale
import kotlin.math.floor

/**
 * Created by Rahul on 19-01-21.
 */
object Utility {

//    fun dpToPx(dp: Float): Float {
//        return dp * Resources.getSystem().displayMetrics.density
//    }
//
//    fun getScreenWidth(): Int {
//        return Resources.getSystem().displayMetrics.widthPixels
//    }
//
//    fun getScreenHeight(): Int {
//        return Resources.getSystem().displayMetrics.heightPixels
//    }

//    fun hideKeyboard(view: View) {
//        if (view.context != null) {
//            val imm =
//                view.context.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
//            imm.hideSoftInputFromWindow(view.windowToken, 0)
//        }
//    }
//
//    fun openKeyboard(view: View) {
//        if (view.context != null) {
//            val imm =
//                view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
//            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
//        }
//    }

//    inline fun <reified T> convertJsonToList(jsonString: String): List<T> {
//        return try {
//            val listType = object : TypeToken<List<T>>() {}.type
//            val containersList = Gson().fromJson<List<T>>(jsonString, listType)
//            containersList
//        } catch (e: Exception) {
//            e.printStackTrace()
//            emptyList()
//        }
//    }
//
//    fun convertNoKeyJsonToList(jsonObject: JsonObject?): List<TimeSlot> {
//        jsonObject ?: return emptyList()
//        return try {
//            val mutableList = mutableListOf<TimeSlot>()
//            val iterator = jsonObject.keySet().iterator()
//            while (iterator.hasNext()) {
//                val key = iterator.next()
//                val value = jsonObject[key].asString
//                val containersItem = TimeSlot(key.toInt(), value)
//                mutableList.add(containersItem)
//            }
//            mutableList
//        } catch (e: Exception) {
//            e.printStackTrace()
//            emptyList()
//        }
//    }

//    fun convertDateToServerFormat(myDate: String): String {
//        try {
//            //val simpleDateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH)
//            val simpleDateFormat = SimpleDateFormat("dd MMM, yyyy", Locale.ENGLISH)
//            val date = simpleDateFormat.parse(myDate)
//            val simpleDateFormat2 = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
//            val sDate = simpleDateFormat2.format(date!!)
//            return sDate
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        return myDate
//    }

    fun getCurrentDate(format: String = "yyyy-MM-dd"): String {
        val calendar = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat(format, Locale.ENGLISH)
        val todayDate = simpleDateFormat.format(calendar.time)
        return todayDate
        /*return "2022-07-11"*/
    }

//    fun getNextDate(): String {
//        val calendar = Calendar.getInstance()
//        calendar.add(Calendar.DAY_OF_MONTH, 1)
//
//        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
//        return sdf.format(calendar.time)
//    }
    fun isTestingEnv() = !(BuildConfig.FLAVOR == "prod" && BuildConfig.BUILD_TYPE == "release")

//    fun getPreviousDate(format: String = "yyyy-MM-dd"): String {
//        val calendar = Calendar.getInstance()
//        calendar.add(Calendar.DAY_OF_MONTH, -1)
//        val simpleDateFormat = SimpleDateFormat(format, Locale.ENGLISH)
//        val todayDate = simpleDateFormat.format(calendar.time)
//        return todayDate
//    }

    fun getSelectedDate(): String = PackagingApplication.appInstance.getAppSettings().deliveryDate

//    fun getDaysDifference(date1: String, date2: String = getCurrentDate("ddMMyy")): Long {
//        return try {
//            val dateFormat = SimpleDateFormat("ddMMyy", Locale.ENGLISH)
//            val mDate1 = dateFormat.parse(date1)!!
//            val mDate2 = dateFormat.parse(date2)!!
//            val difference: Long = kotlin.math.abs(mDate1.time - mDate2.time)
//            difference / (24 * 60 * 60 * 1000)
//        } catch (e: Exception) {
//            e.printStackTrace()
//            0
//        }
//    }

//    fun getHoursDifference(date1: String, date2: String = getCurrentTime()): Long {
//        return try {
//            val newDate1 = changeDateFormat(date1)
//            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
//            val mDate1 = dateFormat.parse(newDate1) ?: return 0
//            val mDate2 = dateFormat.parse(date2) ?: return 0
//            val difference: Long = kotlin.math.abs(mDate1.time - mDate2.time)
//            difference / (60 * 60 * 1000)
//        } catch (e: Exception) {
//            e.printStackTrace()
//            0
//        }
//    }

//    private fun changeDateFormat(date1: String): String {
//        val initDate = SimpleDateFormat("ddMMyy", Locale.ENGLISH).parse(date1)
//        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
//        return initDate?.let { dateFormat.format(it) } ?: date1
//    }

//    fun getMinuteDifference(orderTime: String): Pair<Long, String> {
//        return try {
//            val currentTime = Calendar.getInstance().timeInMillis
//            val orderTimeMs =
//                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(orderTime)
//            if (currentTime < (orderTimeMs?.time ?: currentTime))
//                return 0L to " mins ago"
//            val diff: Long = currentTime - (orderTimeMs?.time ?: currentTime)
//            val seconds = diff / 1000
//            val minutes = seconds / 60
//            val hours = minutes / 60
//            val days = hours / 24
//
//            return when {
//                days > 0 -> days to " days ago"
//                hours > 1 -> hours to " hrs ago"
//                hours > 0 -> hours to " hr ago"
//                minutes > 0 -> minutes to " mins ago"
//                else -> minutes to " mins ago"
//            }
//
//        } catch (e: Exception) {
//            e.printStackTrace()
//            0L to " mins ago"
//        }
//    }

    fun selectTodayOnDateChange(): Boolean {        //pending
        with(PackagingApplication.appInstance.getAppSettings()) {
            val newDate = if (deliveryDay == "today") getCurrentDate() else getNextDate()
            if (deliveryDate != newDate) {
                if (deliveryDay == "today") deliveryDate = newDate
                PackagingApplication.appInstance.showCustomToast(
                    "Showing data for Today (${
                        convertDateToDisplayFormat(
                            deliveryDate
                        )
                    }) ", Toast.LENGTH_LONG
                )
                return true
            }
        }
        return false
    }

//    fun convertDateToDisplayFormat(myDate: String): String {
//        try {
//            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
//            val date = simpleDateFormat.parse(myDate)
//            val simpleDateFormat2 = SimpleDateFormat("dd MMM, yyyy", Locale.ENGLISH)
//            val sDate = simpleDateFormat2.format(date)
//            return sDate
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        return myDate
//    }

//    fun getCurrentTime(): String {
//        val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
//        val currentTime = simpleDateFormat.format(Date())
//        return currentTime
//    }

//    fun getTimeStamp() = System.currentTimeMillis()

    fun <T> safeApi(apiCall: suspend () -> T) = flow {
        try {
            emit(Result.loading())
            val result = apiCall.invoke()
            emit(Result.Success(result))
        } catch (throwable: Throwable) {
            when (throwable) {
                is IOException -> emit(Result.NetworkError())
                is HttpException -> {
                    try {
                        val code = throwable.code()
                        val detail = throwable.response()?.errorBody()?.source().toString()
                        Log.d("ErrorLog", detail)

                        when (detail) {
                            "[size=0]" -> emit(
                                Result.Error(
                                    code,
                                    throwable.localizedMessage
                                )
                            )
                            else -> emit(
                                Result.Error(
                                    code,
                                    detail
                                        .substringAfter(":\"").replace("\"}", "")
                                        .substringBefore("]")
                                        .replace("[text=[\"", "")
                                        .replace("\"", "")
                                )
                            )
                        }
                    } catch (e: Exception) {
                        emit(Result.Error(throwable.code(), null))
                    }
                }
                else -> {
                    emit(Result.Error(null, throwable.localizedMessage))
                }
            }
        }

    }.flowOn(Dispatchers.IO)

    fun getToken() = "Bearer ${PackagingApplication.appInstance.getAppSettings().tokenValue}"
    fun getTimeSlot() = PackagingApplication.appInstance.getAppSettings().timeSlotName
    fun getTimeSlotId() = PackagingApplication.appInstance.getAppSettings().timeSlotId

    fun getShiftName() = PackagingApplication.appInstance.getAppSettings().shiftName
    fun getShiftId() = PackagingApplication.appInstance.getAppSettings().shiftId
    fun getPlantId() = PackagingApplication.appInstance.getAppSettings().plantId

    fun getFranchise() = PackagingApplication.appInstance.getAppSettings().franchise
    fun getFranchiseName() = PackagingApplication.appInstance.getAppSettings().franchiseName
    fun getFranchiseId() = PackagingApplication.appInstance.getAppSettings().franchiseId
    private fun getFranchiseDetail() = PackagingApplication.appInstance.getAppSettings().franchiseDetail

    fun getCentreId(franchiseId: Int): Int? {
        val allCenterDetail = convertJsonToList<FranchiseCenterSummary>(getFranchiseDetail())
        return allCenterDetail.find { it.franchise_id == franchiseId }?.center_id
    }

    fun getFranchiseId(centreId: Int): Int {
        val allCenterDetail = convertJsonToList<FranchiseCenterSummary>(getFranchiseDetail())
        return allCenterDetail.find { it.center_id == centreId }?.franchise_id ?: -1
    }

    fun getInventoryName(inventoryType: Int): String {
        return try {
            val inventoryTypeList =
                convertJsonToList<InventoryType>(PackagingApplication.appInstance.getAppSettings().inventoryType)

            inventoryTypeList.find { it.value == inventoryType }?.name?.replace("_", " ")
                ?: when (inventoryType) {
                    CLOSING_STOCK -> "CLOSING STOCK"
                    RETURN -> "RETURN TO WAREHOUSE"
                    RECONCILIATION -> "RECONCILIATION"
                    else -> "CLOSING STOCK"
                }
        } catch (e: Exception) {
            e.printStackTrace()
            when (inventoryType) {
                CLOSING_STOCK -> "CLOSING STOCK"
                RETURN -> "RETURN TO WAREHOUSE"
                RECONCILIATION -> "RECONCILIATION"
                else -> "CLOSING STOCK"
            }
        }
    }

    fun getTableDetailsList(): List<TableDetails> {
        return try {
            val shiftId = getShiftId()
            //Log.d("kamini ", PackagingApplication.appInstance.getAppSettings().tableShiftDetails)
            val tableList = convertJsonToList<TableDetails>(PackagingApplication.appInstance.getAppSettings().tableDetails)
            return tableList.filter { it.shift == shiftId }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun setOperationStartTime(keyOperationStartTime: String, startTime: String) =
        PackagingApplication.appInstance.getAppSettings()
            .setOperationStartTime(keyOperationStartTime, startTime)

    fun getOperationStartTime(keyOperationStartTime: String) = //getCurrentTime()
        PackagingApplication.appInstance.getAppSettings()
            .getOperationStartTime(keyOperationStartTime).ifEmpty { null }

    fun getOperationEndTime(dispatchStatus: Int) = //getCurrentTime()
        if (dispatchStatus == FULLY_DISPATCHED || dispatchStatus == FULLY_RECEIVED) getCurrentTime() else null

    fun getPrinter() = PackagingApplication.appInstance.getAppSettings().printerModel

    fun isPacker() = PackagingApplication.appInstance.getAppSettings().packagerRole == PACKER
    fun isSuperPacker() =
        PackagingApplication.appInstance.getAppSettings().packagerRole == SUPER_PACKER

    fun isPicker() = PackagingApplication.appInstance.getAppSettings().packagerRole == PICKER
    fun isDispatcher() =
        PackagingApplication.appInstance.getAppSettings().packagerRole == DISPATCHER

    fun isModifier() = PackagingApplication.appInstance.getAppSettings().packagerRole == MODIFIER
    fun isSkuPacker() = PackagingApplication.appInstance.getAppSettings().packagerRole == SKU_PACKER

    fun getAddOns(addOns: List<String>?): Int {
        if (addOns.isNullOrEmpty())
            return 0

        /*val addOns = add_ons.toString()
        return when {
            addOns.equals("[FNV]", true) -> 1
            addOns.contains("FROZEN", true) && !addOns.contains("FNV", true)	-> 2
            addOns.contains("FROZEN", true) || addOns.contains("FROZEN_SCAN_REQUIRED", true) &&  addOns.contains("FNV", true) -> 3
            else -> 0
        }*/

        PackagingApplication.appInstance.getAppSettings().hasBadSkuScanPermission = addOns.contains("Bad_Quality_Scan")

        return when {
            addOns.contains("FNV") && !(addOns.contains("FROZEN") || addOns.contains("FROZEN_SCAN_REQUIRED")) -> 1
            (addOns.contains("FROZEN") || addOns.contains("FROZEN_SCAN_REQUIRED")) && !addOns.contains("FNV")	  -> 2
            (addOns.contains("FROZEN") || addOns.contains("FROZEN_SCAN_REQUIRED")) && addOns.contains("FNV")    -> 3
            else -> 0
        }
    }

    /**/const val AUTHENTICATE: String = "AUTHENTICATE"
    const val ADD_ORDER: String = "ADD_ORDER"
    const val REMOVE_ORDER: String = "REMOVE_ORDER"
    const val GET_PROFILE_INFO: String = "GET_PROFILE_INFO"
    const val REGISTER_PACKER: String = "REGISTER_PACKER"
    const val GET_PRODUCT_THRESHOLD: String = "GET_PRODUCT_THRESHOLD"
    const val GET_CUSTOMER_ORDERS: String = "GET_CUSTOMER_ORDERS"
    const val UNREGISTER_PACKER: String = "UNREGISTER_PACKER"

    fun getWebSocketStatusString(status: String?, orderId: Int?): String {
        return when (status) {
            ADD_ORDER -> "New order($orderId) received for packaging"
            REMOVE_ORDER -> "One order($orderId) is removed"
            CANCELLED -> "One order($orderId) is cancelled"
            else -> ""
        }
    }

        fun getWebSocketCommand(status: String): String =
            JSONObject(PackagingApplication.appInstance.getAppSettings().commandList).optString(
                status,
                ""
            )

        fun getStatus(statusJson: String?, status: String?): String =
            if (statusJson.isNullOrEmpty()) ""
            else JSONObject(statusJson).optString(status ?: "", "")

        fun isStatusDone(orderStatus: String): Boolean {
            return (orderStatus == PACKAGING_DONE || orderStatus == DELIVERED || orderStatus == DB_ALLOCATED
                    || orderStatus == NON_DELIVERED || orderStatus == OUT_FOR_DELIVERY)
        }

        fun getMessageText(str: String): String {
            return when (str) {
                CANCELLED -> "One order is cancelled"
                RECEIVED -> "One order is received"
                PACKAGER_ALLOCATED -> "One order is allocated"
                PACKAGING_PARTIAL -> "One order is partially packed"
                PACKAGING_DONE -> "One order is packed"
                else -> ""
            }

        }

        fun getMacAddress(): String {
            try {
                val all: List<NetworkInterface> =
                    Collections.list(NetworkInterface.getNetworkInterfaces())
                for (nif in all) {
                    if (!nif.name.equals("wlan0", ignoreCase = true)) continue
                    val macBytes: ByteArray = nif.hardwareAddress ?: return ""
                    val res1 = StringBuilder()
                    for (b in macBytes) {
                        res1.append(Integer.toHexString(b.toInt() and 0xFF) + ":")
                    }
                    if (res1.isNotEmpty()) res1.deleteCharAt(res1.length - 1)
                    return res1.toString()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return "02:00:00:00:00:00"
        }

//    fun getCompressedImageFile(context: Context, fileName: String, uri: Uri): File? {
//        return convertByteArrayToFile(fileName, compressImageByteArray(context, uri))
//    }

//    private fun convertByteArrayToFile(fileName: String, imageBytes: ByteArray): File? {
//        if (fileName.isEmpty()) {
//            PackagingApplication.appInstance.showToast(getString(R.string.file_name_must_not_be_empty))
//            return null
//        }
//        return try {
//            val file = File(
//                PackagingApplication.appInstance.externalCacheDir,
//                fileName.replace(".jpeg", "_compressed.jpeg")
//            )
//            file.createNewFile()
//
//            val out = FileOutputStream(file)
//            out.write(imageBytes)
//            out.close()
//            file
//
//        } catch (e: IOException) {
//            e.printStackTrace()
//            PackagingApplication.appInstance.showToast(PackagingApplication.appInstance.getString(R.string.something_went_wrong_try_again_later))
//            null
//        }
//    }
//
//    fun getString(string : Int) : String{
//        return PackagingApplication.appInstance.getString(string)
//    }

//    private fun compressImageByteArray(context: Context, uri: Uri): ByteArray {
//        val maxAttachmentSize = 1024 * 1024 // max final file size
//        val scaleSize = 1024
//        var bmpPic: Bitmap?
//        var bmpPicByteArray: ByteArray? = null
//        try {
//            bmpPic = getThumbnail(context, uri)
//            if (bmpPic != null) {
//                val originalWidth = bmpPic.width
//                val originalHeight = bmpPic.height
//
//                var newWidth = -1
//                var newHeight = -1
//                val multiFactor: Float
//                if (originalHeight > scaleSize || originalWidth > scaleSize) {
//                    when {
//                        originalHeight > originalWidth -> {
//                            newHeight = scaleSize
//                            multiFactor = originalWidth.toFloat() / originalHeight.toFloat()
//                            newWidth = (newHeight * multiFactor).toInt()
//                        }
//                        originalWidth > originalHeight -> {
//                            newWidth = scaleSize
//                            multiFactor = originalHeight.toFloat() / originalWidth.toFloat()
//                            newHeight = (newWidth * multiFactor).toInt()
//                        }
//                        originalHeight == originalWidth -> {
//                            newHeight = scaleSize
//                            newWidth = scaleSize
//                        }
//                    }
//                    bmpPic = Bitmap.createScaledBitmap(bmpPic, newWidth, newHeight, false)
//                }
//                var compressQuality =
//                    104 // decreasing quality by 5% on each loop. (starting from 99%)
//                var streamLength = maxAttachmentSize + 1
//                while (streamLength > maxAttachmentSize) {
//                    val bmpStream = ByteArrayOutputStream()
//                    compressQuality -= 5
//
//                    bmpPic!!.compress(Bitmap.CompressFormat.JPEG, compressQuality, bmpStream)
//                    bmpPicByteArray = bmpStream.toByteArray()
//                    streamLength = bmpPicByteArray.size
//                }
//            }
//        } catch (e: IOException) {
//            e.printStackTrace()
//            PackagingApplication.appInstance.showToast(PackagingApplication.appInstance.getString(R.string.image_compression_failed))
//        }
//        return bmpPicByteArray ?: ByteArray(1)
//    }

//    private fun getThumbnail(context: Context, uri: Uri, thumbnailSIze: Int = 512): Bitmap? {
//        var input = context.contentResolver.openInputStream(uri)
//        val onlyBoundsOptions = BitmapFactory.Options()
//        onlyBoundsOptions.inJustDecodeBounds = true
//        onlyBoundsOptions.inDither = true //optional
//        onlyBoundsOptions.inPreferredConfig = Bitmap.Config.ARGB_8888 //optional
//        BitmapFactory.decodeStream(input, null, onlyBoundsOptions)
//        input!!.close()
//        if (onlyBoundsOptions.outWidth == -1 || onlyBoundsOptions.outHeight == -1) return null
//        val originalSize =
//            if (onlyBoundsOptions.outHeight > onlyBoundsOptions.outWidth) onlyBoundsOptions.outHeight else onlyBoundsOptions.outWidth
//        val ratio =
//            if (originalSize > thumbnailSIze) originalSize / thumbnailSIze.toDouble() else 1.0
//        val bitmapOptions = BitmapFactory.Options()
//        bitmapOptions.inSampleSize = getPowerOfTwoForSampleRatio(ratio)
//        bitmapOptions.inDither = true //optional
//        bitmapOptions.inPreferredConfig = Bitmap.Config.ARGB_8888 //optional
//        input = context.contentResolver.openInputStream(uri)
//        var bitmap = BitmapFactory.decodeStream(input, null, bitmapOptions)
//        bitmap = rotateBitmap(uri, bitmap ?: return null)
//        input!!.close()
//        return bitmap
//    }

//    private fun getPowerOfTwoForSampleRatio(ratio: Double): Int {
//        val k = Integer.highestOneBit(floor(ratio).toInt())
//        return if (k == 0) 1 else k
//    }

//    private fun rotateBitmap(uri: Uri, bitmap: Bitmap) : Bitmap? {
//        try {
//            val exifInterface = ExifInterface(uri.path!!)
//            val orientation: Int = exifInterface.getAttributeInt(
//                ExifInterface.TAG_ORIENTATION,
//                ExifInterface.ORIENTATION_UNDEFINED
//            )
//            return when (orientation) {
//                ExifInterface.ORIENTATION_TRANSPOSE, ExifInterface.ORIENTATION_ROTATE_90 -> rotateBitmap(bitmap, 90f)
//                ExifInterface.ORIENTATION_ROTATE_180 -> rotateBitmap(bitmap, 180f)
//                ExifInterface.ORIENTATION_ROTATE_270 -> rotateBitmap(bitmap, 270f)
//                ExifInterface.ORIENTATION_NORMAL -> bitmap
//                else -> bitmap
//            }
//
//            // Use the rotatedBitmap for further processing or display
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        return null
//    }

    // Method to rotate the bitmap
//    private fun rotateBitmap(bitmap: Bitmap, degrees: Float): Bitmap? {
//        val matrix = Matrix()
//        matrix.postRotate(degrees)
//        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
//    }

    fun isTimeBefore30Min(updatedTime: Long?): Int {
        val timeBefore30min = getTimeStamp() - (30 * 60 * 1000)
        return if (updatedTime == null || (timeBefore30min >= updatedTime && updatedTime > 0)) {
            SERVER_DATA
        } else if (updatedTime == 0L){
            NO_DATA
        } else LOCAL_DATA
    }

}